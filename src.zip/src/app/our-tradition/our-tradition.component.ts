import { Component } from '@angular/core';

@Component({
  selector: 'app-our-tradition',
  templateUrl: './our-tradition.component.html'
})

export class OurTraditionComponent{ }

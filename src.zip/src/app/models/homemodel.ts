export interface HomeModel {
  name: string,
  email: string
}

import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

import { HomeModel } from '../models/homemodel';

@Injectable({
    providedIn: 'root'
})
export class RakyanService {
    //private homeApiUrl: 'http://dev.di91.com/rakyan/wp-admin/admin-ajax.php/?action=get_home_data';
    //private ourTraditionApiUrl: 'http://dev.di91.com/rakyan/wp-admin/admin-ajax.php/?action=get_our_tradition_data';
    private url: string = 'http://localhost:4200/assets/data1.json';
    constructor( private http: HttpClient ) {}

    getHomeData(){
      return this.http.get<HomeModel>(this.url)
      .pipe(
          catchError(this.handleError)
      );
    }


    private handleError (error: HttpErrorResponse) {
      //console.error('ApiService::handleError', error);
      return Observable.throw(error.error.message || 'Server error');
    }
}

import { Component } from '@angular/core';

@Component({
  selector: 'app-treasure',
  templateUrl: './treasure.component.html'
})

export class TreasureComponent {}

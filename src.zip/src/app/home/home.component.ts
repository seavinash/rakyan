import { Component, OnInit } from '@angular/core';

import { RakyanService } from '../services/rakyanservice';
import { HomeModel } from '../models/homemodel';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html'
})

export class HomeComponent {


  public errorMsg;
  dataList: HomeModel;
  constructor(private rakyanservice: RakyanService){}

  ngOnInit() {
      this.rakyanservice.getHomeData()
      .subscribe( (data: HomeModel) => {
          this.dataList = data;
      }, (error) => {
          this.errorMsg = error;
      });
  }


}
